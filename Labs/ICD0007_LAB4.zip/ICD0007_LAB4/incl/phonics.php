<?php

$vowels = array("A", "E", "I", "O", "U");


?>